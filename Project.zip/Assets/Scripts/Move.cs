﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class Move : MonoBehaviour {
    public float moveSpeed = 5.0f;
    Rigidbody rb;
    bool ho = true;
    

	// Use this for initialization
	void Start () {
        rb = GetComponent<Rigidbody>();

	}
	

	// Update is called once per frame
	void Update () {

       if(!Pause.pause)
       {
            moving();
            if (!EventSystem.current.IsPointerOverGameObject())
            {
                print("Mouse On");
                //이벤트 시스템. 현재 마우스 커서의 포인트가 올라가있는 오브젝트가 UI인지 아닌지 (True, false)
                if (Input.GetMouseButtonDown(0))
                {
                    if (ho == false)
                    {
                        ho = true;
                    }
                    else
                    {
                        ho = false;
                    }
                }
            }
       }
    }

    void moving()
    {
        if(ho)
        {
        transform.Translate(moveSpeed * Time.deltaTime, 0, 0);

        }
        else
        {
            transform.Translate(-moveSpeed * Time.deltaTime, 0, 0);
        }
        if(Input.GetButtonDown("Jump"))
        {
            print("jumping");
            rb.AddForce(Vector3.up * 100f);
        }
      
    }
}
