﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class Health : MonoBehaviour {
    public  GameObject GreenHealthCircle;
    Image Img;
    // Update is called once per frame
    private void Start()
    {
        Img = GetComponent<Image>();
    }
    void Update () {
        if(Input.GetKey(KeyCode.H))
        {
        

        }
	}
}
